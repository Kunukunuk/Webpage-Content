To run the code do javac Main.java on command line.
It works with pdf, txt, html, htm, jpg, jpeg, and gif files.
Provided are the output files of each type of files.
The gif file works when opened with internet explorer but not with my own window media for some reason.
Please use internet explorer to see if the gif works.